CAB230 project :)

We are creating an AI powered quiz maker and student progress tracker that both students and teachers can use as a teaching and learning aid.
Note to tutors - sac505 and SashaPetrenk0 are the same person, I have been having issues with switching between my personal and uni github accounts and am not sure how to fix this yet. 
