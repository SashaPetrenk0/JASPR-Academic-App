package org.jaspr.hr.demo;

public interface ResponseListener {
    public void onResponseReceived(OllamaResponse response);
}
